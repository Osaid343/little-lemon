export enum FooterSectionType {
	Location = "Location",
	Phone = "Phone Number",
	Hours = "Opening Hours",
}
