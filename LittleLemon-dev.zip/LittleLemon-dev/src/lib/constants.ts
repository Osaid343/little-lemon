export const NAV_LINKS_CONFIG = [
	{
		label: "Home",
		href: "/",
	},
	{
		label: "Menu",
		href: "menu",
	},
	{
		label: "Reserve a table",
		href: "/reserve",
	},
];
